#' Targeted Guttman-Scale Imputation of Misfit Ordinal Responses
#'
#' The main user-facing function.  Executes the complete pipeline in a single
#' call:
#'
#' 1. Rearranges the response matrix into **Guttman order** (rows sorted by
#'    descending person total scores, columns by descending item total scores).
#'    The output has the **same dimensions** as the input — no persons or items
#'    are dropped.
#' 2. Fits a **Partial Credit Model** (PCM) via [eRm::PCM()] and extracts
#'    Outfit/Infit MSQ statistics and standardised *z*-scores.
#' 3. Identifies **misfit persons and items** whose MSQ falls outside
#'    `[msq_lower, msq_upper]` *and* whose |*z*| exceeds `z_threshold`.
#' 4. Replaces each cell at the **intersection of misfit persons × items** in
#'    the Guttman matrix with the nearest integer to the average of its
#'    surrounding neighbours (neighbourhood radius `k`).
#' 5. Returns the imputed matrix in the **original row/column order** — only
#'    the targeted misfit-intersection cells differ from the raw input; every
#'    other cell is unchanged.
#' 6. Optionally **saves** the Guttman-ordered matrix and the final imputed
#'    matrix as XLSX or CSV files.
#'
#' @section Output dimensions:
#' Both saved files and in-memory matrices always preserve the full
#' `n_persons × n_items` dimensions of the input:
#' \itemize{
#'   \item **Guttman data** (`$guttman_data`): same shape as input, rows
#'     sorted by descending person total, columns by descending item total.
#'   \item **Imputed data** (`$imputed_data`): same shape and row/column
#'     *order* as the input; only misfit-intersection cells are changed.
#' }
#'
#' @param data A numeric matrix or data frame of ordinal responses
#'   (persons in rows, items in columns).  Row and column names are used as
#'   person and item IDs; sequential labels are assigned if absent.
#' @param msq_lower Numeric scalar >= 0. Lower bound of the acceptable
#'   Outfit/Infit MSQ range.  Default: `0.8`.
#' @param msq_upper Numeric scalar > `msq_lower`. Upper bound of the
#'   acceptable MSQ range.  Default: `1.2`.
#' @param z_threshold Numeric scalar > 0. Absolute standardised *z*-score
#'   threshold (second misfit criterion).  Default: `1.96`
#'   (approx two-tailed p < .05).
#' @param k Positive integer. Neighbourhood radius.  `k = 1` (default) uses
#'   a 3 × 3 window (up to 8 neighbours); `k = 2` uses 5 × 5, etc.
#' @param save_guttman Logical. If `TRUE`, the Guttman-ordered matrix is
#'   saved to `guttman_file`.  Default: `FALSE`.
#' @param save_imputed Logical. If `TRUE`, the final imputed matrix
#'   (in original row/column order) is saved to `imputed_file`.
#'   Default: `FALSE`.
#' @param guttman_file Character. File path for the Guttman-ordered output.
#'   Use `.xlsx` extension for Excel (requires **openxlsx**) or `.csv` for
#'   plain text.  Default: `"guttman_ordered.xlsx"`.
#' @param imputed_file Character. File path for the imputed output.
#'   Default: `"imputed_data.xlsx"`.
#' @param id_col Character. Name of the person-ID column written as the first
#'   column in saved files.  Default: `"PersonID"`.
#' @param verbose Logical. If `TRUE` (default), progress messages and a
#'   summary are printed.
#'
#' @return An object of class `"guttman_impute"` — a named list:
#' \describe{
#'   \item{`imputed_data`}{Numeric matrix, **original row/column order**,
#'     with only misfit-intersection cells replaced.}
#'   \item{`guttman_data`}{Numeric matrix, **Guttman order**
#'     (pre-imputation).}
#'   \item{`imputed_guttman`}{Numeric matrix, **Guttman order**
#'     (post-imputation).}
#'   \item{`person_fit`}{Data frame of person Outfit/Infit MSQ and z-scores.}
#'   \item{`item_fit`}{Data frame of item Outfit/Infit MSQ and z-scores.}
#'   \item{`misfit_persons`}{Character vector of misfit person IDs.}
#'   \item{`misfit_items`}{Character vector of misfit item IDs.}
#'   \item{`imputed_log`}{Data frame recording every imputed cell with columns
#'     `person`, `item`, `guttman_row`, `guttman_col`, `old_value`,
#'     `new_value`, `n_neighbours`.}
#'   \item{`params`}{Named list of threshold parameters used.}
#' }
#'
#' @references
#' Balbuena, S. E. (2024). A method for imputing ordinal responses from the
#' intersection of misfitting items and persons in a Guttman scale.
#' *Manuscript submitted for publication.*
#'
#' @examples
#' set.seed(42)
#' dat <- matrix(sample(1:5, 150, replace = TRUE), nrow = 30,
#'               dimnames = list(paste0("P", 1:30), paste0("I", 1:5)))
#'
#' result <- guttman_impute(dat, msq_lower = 0.8, msq_upper = 1.2)
#' result
#'
#' # Dimensions are always preserved
#' stopifnot(identical(dim(result$guttman_data), dim(dat)))
#' stopifnot(identical(dim(result$imputed_data), dim(dat)))
#'
#' # imputed_data is in original order; only misfit cells changed
#' stopifnot(identical(rownames(result$imputed_data), rownames(dat)))
#' stopifnot(identical(colnames(result$imputed_data), colnames(dat)))
#'
#' # Save to Excel
#' \dontrun{
#' guttman_impute(dat,
#'                save_guttman = TRUE, guttman_file = "guttman.xlsx",
#'                save_imputed = TRUE, imputed_file = "imputed.xlsx")
#' }
#'
#' @export
guttman_impute <- function(data,
                            msq_lower    = 0.8,
                            msq_upper    = 1.2,
                            z_threshold  = 1.96,
                            k            = 1,
                            save_guttman = FALSE,
                            save_imputed = FALSE,
                            guttman_file = "guttman_ordered.xlsx",
                            imputed_file = "imputed_data.xlsx",
                            id_col       = "PersonID",
                            verbose      = TRUE) {

  .validate_thresholds(msq_lower, msq_upper, z_threshold)

  if (!is.numeric(k) || length(k) != 1L || k < 1 || k != round(k))
    stop("`k` must be a single positive integer.", call. = FALSE)

  mat <- .to_matrix(data)

  # ── Step 1: Guttman ordering ─────────────────────────────────────────────
  # Rows sorted by descending person total; columns by descending item total.
  # Dimensions are IDENTICAL to input — no persons or items are dropped.
  if (verbose) message("[1/5] Applying Guttman ordering...")
  guttman_mat <- guttman_order(mat)

  # ── Step 2: Rasch PCM fit ────────────────────────────────────────────────
  if (verbose) message("[2/5] Fitting Partial Credit Model (PCM) via eRm...")
  fit_results <- rasch_fit(guttman_mat)

  # ── Step 3: Misfit detection ─────────────────────────────────────────────
  if (verbose) message("[3/5] Identifying misfit persons and items...")
  misfit_persons <- identify_misfit(fit_results$person_fit,
                                    msq_lower, msq_upper, z_threshold)
  misfit_items   <- identify_misfit(fit_results$item_fit,
                                    msq_lower, msq_upper, z_threshold)

  # ── Step 4: Targeted imputation on Guttman matrix ───────────────────────
  # Only cells at the intersection of misfit persons x misfit items are
  # replaced.  All other cells keep their original values.
  if (verbose) message("[4/5] Imputing misfit-intersection cells...")
  imputed_guttman <- impute_guttman(guttman_mat, misfit_persons,
                                    misfit_items, k = k)
  imputed_log <- attr(imputed_guttman, "imputed_log")

  # ── Step 5: Restore original order ──────────────────────────────────────
  # Re-index back to the original person/item layout.
  # Result: original dimensions, original order, targeted cells replaced.
  if (verbose) message("[5/5] Restoring original row/column order...")
  imputed_data <- restore_order(imputed_guttman)

  # Sanity checks — dimensions and names must always match the input exactly
  if (!identical(dim(imputed_data), dim(mat)))
    stop("[guttmanimpute] BUG: imputed_data dimensions differ from input. Please report.",
         call. = FALSE)
  if (!identical(dim(guttman_mat), dim(mat)))
    stop("[guttmanimpute] BUG: guttman_data dimensions differ from input. Please report.",
         call. = FALSE)
  if (!identical(rownames(imputed_data), rownames(mat)))
    stop("[guttmanimpute] BUG: imputed_data rownames differ from input. Please report.",
         call. = FALSE)
  if (!identical(colnames(imputed_data), colnames(mat)))
    stop("[guttmanimpute] BUG: imputed_data colnames differ from input. Please report.",
         call. = FALSE)

  # ── Optional file output ─────────────────────────────────────────────────
  if (save_guttman) {
    .save_matrix(guttman_mat, guttman_file, id_col)
    if (verbose) message("  Guttman-ordered data saved to: ", guttman_file)
  }

  if (save_imputed) {
    .save_matrix(imputed_data, imputed_file, id_col)
    if (verbose) message("  Imputed data saved to: ", imputed_file)
  }

  # ── Assemble result object ───────────────────────────────────────────────
  result <- structure(
    list(
      imputed_data    = imputed_data,
      guttman_data    = guttman_mat,
      imputed_guttman = imputed_guttman,
      person_fit      = fit_results$person_fit,
      item_fit        = fit_results$item_fit,
      misfit_persons  = misfit_persons,
      misfit_items    = misfit_items,
      imputed_log     = imputed_log,
      params          = list(
        msq_lower   = msq_lower,
        msq_upper   = msq_upper,
        z_threshold = z_threshold,
        k           = k
      )
    ),
    class = "guttman_impute"
  )

  if (verbose) .print_summary(result)
  invisible(result)
}


# =============================================================================
# File save helper
# =============================================================================

# .save_matrix(mat, file, id_col)
#
# Saves a numeric matrix to disk with person IDs as the first named column,
# preserving the exact n_persons x n_items shape of the data.
#
# Format is chosen by file extension:
#   .xlsx  -> openxlsx::write.xlsx()   (preferred; clean Excel with headers)
#   .csv   -> utils::write.csv() with row.names = FALSE, person IDs inlined
#   other  -> same as CSV
#
# Why NOT write.csv(mat)?
#   write.csv() emits an unnamed first column of row names.  When the file
#   is opened in Excel or read back with read.csv() (without row.names=1)
#   that column appears as an extra "X" column, inflating dimensions from
#   n x p to n x (p+1).  Here we always inline the person IDs as a proper
#   named column so both Excel and read.csv() / read.xlsx() return a clean
#   n x (p+1) frame (PersonID + p item columns) — the data itself is n x p.
#
# @param mat    Numeric matrix with row and column names.
# @param file   Output file path.
# @param id_col Name for the person-ID column (default "PersonID").
# @keywords internal
.save_matrix <- function(mat, file, id_col = "PersonID") {

  # Build a data frame: person IDs as first column, item scores as the rest
  df <- data.frame(
    setNames(list(rownames(mat)), id_col),
    as.data.frame(mat, check.names = FALSE),
    check.names = FALSE,
    stringsAsFactors = FALSE
  )

  # Validate path is writable before attempting to open connection
  .validate_save_path(file)

  ext <- tolower(tools::file_ext(file))

  if (ext == "xlsx") {
    if (!requireNamespace("openxlsx", quietly = TRUE)) {
      warning(
        "Package 'openxlsx' is required to write .xlsx files. ",
        "Saving as CSV instead: ", sub("\\.xlsx$", ".csv", file, ignore.case = TRUE),
        call. = FALSE
      )
      file <- sub("\\.xlsx$", ".csv", file, ignore.case = TRUE)
      utils::write.csv(df, file = file, row.names = FALSE)
    } else {
      openxlsx::write.xlsx(df, file = file, rowNames = FALSE, overwrite = TRUE)
    }
  } else {
    utils::write.csv(df, file = file, row.names = FALSE)
  }

  invisible(file)
}


# =============================================================================
# S3 methods
# =============================================================================

#' Print a `guttman_impute` Object
#'
#' Displays a concise summary of the imputation results.
#'
#' @param x A `guttman_impute` object returned by [guttman_impute()].
#' @param ... Ignored.
#' @return `x`, invisibly.
#' @export
print.guttman_impute <- function(x, ...) {
  .print_summary(x)
  invisible(x)
}


#' Summarise a `guttman_impute` Object
#'
#' Prints a full summary including fit statistics and the imputation log.
#'
#' @param object A `guttman_impute` object returned by [guttman_impute()].
#' @param ... Ignored.
#' @return `object`, invisibly.
#' @export
summary.guttman_impute <- function(object, ...) {

  cat("\n=== guttmanimpute: Imputation Summary ===\n\n")
  cat("Dataset dimensions  :", nrow(object$imputed_data), "persons x",
      ncol(object$imputed_data), "items\n")
  cat("Guttman data dims   :", nrow(object$guttman_data), "x",
      ncol(object$guttman_data), "(same shape, sorted by row/col totals)\n")
  cat("Imputed data dims   :", nrow(object$imputed_data), "x",
      ncol(object$imputed_data),
      "(original order; only misfit-intersection cells changed)\n\n")

  cat("Thresholds used:\n")
  cat("  MSQ acceptable range :", object$params$msq_lower, "to",
      object$params$msq_upper, "\n")
  cat("  |z| threshold        :", object$params$z_threshold, "\n")
  cat("  Neighbourhood radius : k =", object$params$k, "\n\n")

  cat("--- Person Fit Statistics ---\n")
  print(round(object$person_fit, 4))

  cat("\n--- Item Fit Statistics ---\n")
  print(round(object$item_fit, 4))

  cat("\nMisfit persons (", length(object$misfit_persons), "):",
      if (length(object$misfit_persons) > 0)
        paste(object$misfit_persons, collapse = ", ") else "none", "\n")
  cat("Misfit items   (", length(object$misfit_items), "):",
      if (length(object$misfit_items) > 0)
        paste(object$misfit_items, collapse = ", ") else "none", "\n")

  cat("\n--- Imputation Log (", nrow(object$imputed_log), "cells) ---\n")
  if (nrow(object$imputed_log) == 0) {
    cat("  No cells were imputed.\n")
  } else {
    print(object$imputed_log)
  }

  invisible(object)
}


# ── Internal print helper ─────────────────────────────────────────────────────

.print_summary <- function(x) {
  n_imp <- nrow(x$imputed_log)
  cat("\n--- guttmanimpute results ---\n")
  cat("  Persons          :", nrow(x$imputed_data), "\n")
  cat("  Items            :", ncol(x$imputed_data), "\n")
  cat("  MSQ range        :", x$params$msq_lower, "to", x$params$msq_upper, "\n")
  cat("  Misfit persons   :", length(x$misfit_persons),
      if (length(x$misfit_persons) > 0)
        paste0("(", paste(x$misfit_persons, collapse = ", "), ")") else "", "\n")
  cat("  Misfit items     :", length(x$misfit_items),
      if (length(x$misfit_items) > 0)
        paste0("(", paste(x$misfit_items, collapse = ", "), ")") else "", "\n")
  cat("  Cells imputed    :", n_imp, "\n")
  if (n_imp > 0) {
    cat("  Changed cells    :\n")
    print(x$imputed_log[, c("person", "item", "old_value", "new_value")])
  }
  cat("-----------------------------\n")
}
