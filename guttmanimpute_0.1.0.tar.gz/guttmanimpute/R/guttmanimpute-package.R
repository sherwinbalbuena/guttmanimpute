#' @keywords internal
#' @aliases guttmanimpute-package
"_PACKAGE"

#' @importFrom eRm PCM person.parameter personfit itemfit
NULL
