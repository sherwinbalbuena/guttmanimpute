# Internal utility functions — not exported

# Convert a data.frame or matrix to a plain numeric matrix.
#
# CRITICAL: row and column names are ALWAYS preserved from the input,
# even when they are the default numeric-string rownames ("1","2",...).
# We only assign synthetic labels (P1..Pn / I1..In) when rownames are
# truly NULL (i.e., the object has no rownames attribute at all).
# This ensures restore_order() can always map back to the original layout.
.to_matrix <- function(data) {

  if (!is.matrix(data) && !is.data.frame(data)) {
    stop("`data` must be a numeric matrix or data frame.", call. = FALSE)
  }

  # Capture names BEFORE coercion (as.matrix may drop them in edge cases)
  orig_rn <- rownames(data)
  orig_cn <- colnames(data)

  mat <- as.matrix(data)

  if (!is.numeric(mat)) {
    stop("`data` must contain only numeric values.", call. = FALSE)
  }

  # Restore names captured before coercion
  rownames(mat) <- orig_rn
  colnames(mat) <- orig_cn

  # Only assign synthetic labels when names are truly absent (NULL)
  if (is.null(rownames(mat))) {
    rownames(mat) <- paste0("P", seq_len(nrow(mat)))
  }
  if (is.null(colnames(mat))) {
    colnames(mat) <- paste0("I", seq_len(ncol(mat)))
  }

  mat
}


# Validate MSQ lower/upper bounds and z-threshold
.validate_thresholds <- function(msq_lower, msq_upper, z_threshold) {

  if (!is.numeric(msq_lower) || length(msq_lower) != 1L || msq_lower < 0) {
    stop("`msq_lower` must be a single non-negative number.", call. = FALSE)
  }
  if (!is.numeric(msq_upper) || length(msq_upper) != 1L ||
      msq_upper <= msq_lower) {
    stop("`msq_upper` must be a single number greater than `msq_lower`.",
         call. = FALSE)
  }
  if (!is.numeric(z_threshold) || length(z_threshold) != 1L ||
      z_threshold <= 0) {
    stop("`z_threshold` must be a single positive number.", call. = FALSE)
  }

  invisible(NULL)
}


# Validate that a save path is writable, with a clear actionable message.
.validate_save_path <- function(file) {
  dir_path <- dirname(normalizePath(file, mustWork = FALSE))
  if (!dir.exists(dir_path)) {
    stop(
      "Directory does not exist: ", dir_path, "\n",
      "Use an absolute path to an existing directory, e.g.:\n",
      "  guttman_file = file.path(getwd(), \"guttman_ordered.xlsx\")",
      call. = FALSE
    )
  }
  if (file.access(dir_path, 2L) != 0L) {
    stop(
      "No write permission for directory: ", dir_path, "\n",
      "Use an absolute path to a writable directory, e.g.:\n",
      "  guttman_file = file.path(getwd(), \"guttman_ordered.xlsx\")",
      call. = FALSE
    )
  }
  invisible(TRUE)
}


# Package-level mutable state (environments are not locked by R's namespace seal)
.pkg_state <- new.env(parent = emptyenv())
.pkg_state$erm_patched <- FALSE
