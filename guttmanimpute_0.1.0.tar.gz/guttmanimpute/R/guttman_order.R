#' Rearrange a Response Matrix into Guttman Order
#'
#' Sorts rows by descending person total scores and columns by descending item
#' total scores, producing a Guttman scalogram in which high-ability persons
#' appear first (top) and high-frequency (easier) items appear first (left).
#' The original row and column names are preserved as attributes so the matrix
#' can be [restored][restore_order] after imputation.
#'
#' @param data A numeric matrix or data frame of ordinal responses
#'   (persons × items). Row names are treated as person IDs and column names
#'   as item IDs. If unnamed, sequential labels (`P1`, `P2`, … / `I1`, `I2`,
#'   …) are assigned automatically.
#'
#' @return A numeric matrix with the same dimensions as `data`, rearranged in
#'   Guttman order.  Three attributes are attached:
#'   \describe{
#'     \item{`orig_row_order`}{Character vector of row names in the
#'       *original* order.}
#'     \item{`orig_col_order`}{Character vector of column names in the
#'       *original* order.}
#'     \item{`row_totals`}{Named numeric vector of person total scores
#'       (computed before column sorting).}
#'     \item{`col_totals`}{Named numeric vector of item total scores
#'       (computed after row sorting).}
#'   }
#'
#' @examples
#' set.seed(1)
#' dat <- matrix(sample(1:5, 40, replace = TRUE), nrow = 8,
#'               dimnames = list(paste0("P", 1:8), paste0("I", 1:5)))
#' gmat <- guttman_order(dat)
#' gmat
#'
#' @export
guttman_order <- function(data) {

  mat <- .to_matrix(data)

  orig_row_order <- rownames(mat)
  orig_col_order <- colnames(mat)

  # Step 1: sort rows by decreasing person total score
  row_totals  <- rowSums(mat, na.rm = TRUE)
  sorted_rows <- order(row_totals, decreasing = TRUE)
  mat_sorted  <- mat[sorted_rows, , drop = FALSE]

  # Step 2: sort columns by decreasing item total score
  col_totals  <- colSums(mat_sorted, na.rm = TRUE)
  sorted_cols <- order(col_totals, decreasing = TRUE)
  mat_guttman <- mat_sorted[, sorted_cols, drop = FALSE]

  attr(mat_guttman, "orig_row_order") <- orig_row_order
  attr(mat_guttman, "orig_col_order") <- orig_col_order
  attr(mat_guttman, "row_totals")     <- sort(row_totals, decreasing = TRUE)
  attr(mat_guttman, "col_totals")     <- col_totals[sorted_cols]

  mat_guttman
}


#' Restore a Guttman-Ordered Matrix to Its Original Row/Column Order
#'
#' Re-indexes a matrix that was produced (or derived from) [guttman_order()]
#' back to the original person/item layout using the `orig_row_order` and
#' `orig_col_order` attributes.
#'
#' @param guttman_mat A numeric matrix carrying `orig_row_order` and
#'   `orig_col_order` attributes (as returned by [guttman_order()] or
#'   [impute_guttman()]).
#'
#' @return A numeric matrix in the original row/column order.
#'
#' @examples
#' set.seed(1)
#' dat  <- matrix(sample(1:5, 40, replace = TRUE), nrow = 8,
#'                dimnames = list(paste0("P", 1:8), paste0("I", 1:5)))
#' gmat <- guttman_order(dat)
#' identical(restore_order(gmat), dat)   # TRUE
#'
#' @export
restore_order <- function(guttman_mat) {

  orig_row <- attr(guttman_mat, "orig_row_order")
  orig_col <- attr(guttman_mat, "orig_col_order")

  if (is.null(orig_row) || is.null(orig_col)) {
    stop(
      "`guttman_mat` does not carry `orig_row_order` / `orig_col_order` ",
      "attributes.  Pass a matrix returned by `guttman_order()` or ",
      "`impute_guttman()`.",
      call. = FALSE
    )
  }

  guttman_mat[orig_row, orig_col, drop = FALSE]
}
