# ── helpers ──────────────────────────────────────────────────────────────────
make_data <- function(n = 30, p = 5, seed = 42) {
  set.seed(seed)
  matrix(sample(1:5, n * p, replace = TRUE), nrow = n,
         dimnames = list(paste0("P", 1:n), paste0("I", 1:p)))
}

# ── dimension guarantees ──────────────────────────────────────────────────────

test_that("guttman_data has identical dimensions to input", {
  dat    <- make_data()
  result <- guttman_impute(dat, verbose = FALSE)
  expect_equal(dim(result$guttman_data), dim(dat))
})

test_that("imputed_data has identical dimensions to input", {
  dat    <- make_data()
  result <- guttman_impute(dat, verbose = FALSE)
  expect_equal(dim(result$imputed_data), dim(dat))
})

test_that("guttman_data contains all original persons and items", {
  dat    <- make_data()
  result <- guttman_impute(dat, verbose = FALSE)
  expect_setequal(rownames(result$guttman_data), rownames(dat))
  expect_setequal(colnames(result$guttman_data), colnames(dat))
})

test_that("guttman_data rows are sorted by descending person total", {
  dat    <- make_data()
  result <- guttman_impute(dat, verbose = FALSE)
  row_tots <- rowSums(result$guttman_data)
  expect_true(all(diff(row_tots) <= 0),
              label = "Row totals must be non-increasing (Guttman order)")
})

test_that("guttman_data columns are sorted by descending item total", {
  dat    <- make_data()
  result <- guttman_impute(dat, verbose = FALSE)
  col_tots <- colSums(result$guttman_data)
  expect_true(all(diff(col_tots) <= 0),
              label = "Column totals must be non-increasing (Guttman order)")
})

# ── original-order guarantee ──────────────────────────────────────────────────

test_that("imputed_data has the same row order as the original input", {
  dat    <- make_data()
  result <- guttman_impute(dat, verbose = FALSE)
  expect_identical(rownames(result$imputed_data), rownames(dat))
})

test_that("imputed_data has the same column order as the original input", {
  dat    <- make_data()
  result <- guttman_impute(dat, verbose = FALSE)
  expect_identical(colnames(result$imputed_data), colnames(dat))
})

test_that("rownames are preserved when input has default numeric-string rownames", {
  # data.frame default rownames are "1","2",...; must survive the full pipeline
  set.seed(10)
  df <- data.frame(matrix(sample(1:5, 150, replace = TRUE), nrow = 30,
                          dimnames = list(NULL, paste0("I", 1:5))))
  expect_equal(rownames(df), as.character(1:30))   # sanity

  result <- guttman_impute(df, verbose = FALSE)
  expect_identical(rownames(result$imputed_data), rownames(df))
  expect_identical(rownames(result$guttman_data),
                   rownames(df)[order(rowSums(df), decreasing = TRUE)])
})

test_that("rownames are preserved when input has custom string rownames", {
  set.seed(11)
  mat <- matrix(sample(1:5, 30, replace = TRUE), nrow = 6,
                dimnames = list(paste0("STU", 1:6), paste0("ITEM", 1:5)))
  result <- suppressWarnings(guttman_impute(mat, verbose = FALSE))
  expect_identical(rownames(result$imputed_data), rownames(mat))
  expect_equal(dim(result$imputed_data), dim(mat))
})

# ── targeted-imputation guarantee ─────────────────────────────────────────────

test_that("only misfit-intersection cells differ from original in imputed_data", {
  set.seed(1)
  dat <- matrix(sample(1:5, 300, replace = TRUE, prob = c(.5,.25,.12,.08,.05)),
                nrow = 60,
                dimnames = list(paste0("P", 1:60), paste0("I", 1:5)))
  result <- guttman_impute(dat, msq_lower = 0.5, msq_upper = 1.5,
                            z_threshold = 1.0, verbose = FALSE)

  # Dimension invariant always holds
  expect_equal(dim(result$imputed_data), dim(dat))

  changed_idx <- which(dat != result$imputed_data, arr.ind = TRUE)
  if (nrow(changed_idx) > 0) {
    changed_persons <- rownames(dat)[changed_idx[, 1]]
    changed_items   <- colnames(dat)[changed_idx[, 2]]
    expect_true(all(changed_persons %in% result$misfit_persons))
    expect_true(all(changed_items   %in% result$misfit_items))
  } else {
    expect_true(length(result$misfit_persons) == 0 |
                length(result$misfit_items)   == 0 |
                nrow(result$imputed_log)       == 0)
  }
})

test_that("cells outside misfit intersection are identical to original", {
  set.seed(2)
  dat <- matrix(sample(1:5, 150, replace = TRUE), nrow = 30,
                dimnames = list(paste0("P", 1:30), paste0("I", 1:5)))
  result <- guttman_impute(dat, verbose = FALSE)

  mp <- result$misfit_persons
  mi <- result$misfit_items

  if (length(mp) > 0 && length(mi) > 0) {
    # Build logical mask of misfit-intersection cells (original order)
    mask <- matrix(FALSE, nrow(dat), ncol(dat),
                   dimnames = dimnames(dat))
    mask[mp, mi] <- TRUE

    # All non-masked cells must be unchanged
    expect_true(
      all(dat[!mask] == result$imputed_data[!mask]),
      label = "Non-misfit cells must be unchanged"
    )
  } else {
    # No misfits -> imputed_data identical to input
    expect_identical(result$imputed_data, dat)
  }
})

# ── return object structure ───────────────────────────────────────────────────

test_that("guttman_impute returns a guttman_impute object with expected names", {
  result <- guttman_impute(make_data(), verbose = FALSE)
  expect_s3_class(result, "guttman_impute")
  expect_named(result, c("imputed_data", "guttman_data", "imputed_guttman",
                          "person_fit", "item_fit", "misfit_persons",
                          "misfit_items", "imputed_log", "params"))
})

test_that("params list stores the supplied threshold values", {
  dat    <- make_data()
  result <- guttman_impute(dat, msq_lower = 0.7, msq_upper = 1.3,
                            z_threshold = 2.0, k = 2, verbose = FALSE)
  expect_equal(result$params$msq_lower,   0.7)
  expect_equal(result$params$msq_upper,   1.3)
  expect_equal(result$params$z_threshold, 2.0)
  expect_equal(result$params$k,           2L)
})

# ── file save: XLSX ───────────────────────────────────────────────────────────

test_that(".save_matrix writes XLSX with correct n_persons x (1 + n_items) shape", {
  dat  <- make_data(n = 10, p = 4)
  tmp  <- tempfile(fileext = ".xlsx")
  .save_matrix(dat, tmp, id_col = "PersonID")

  back <- openxlsx::read.xlsx(tmp)
  # Expect n rows, (1 + p) cols: PersonID + item columns
  expect_equal(nrow(back), nrow(dat))
  expect_equal(ncol(back), ncol(dat) + 1L)    # +1 for PersonID column
  expect_equal(colnames(back)[1], "PersonID")
  expect_equal(colnames(back)[-1], colnames(dat))
  expect_equal(back$PersonID, rownames(dat))
})

test_that(".save_matrix writes CSV with correct shape (no phantom row-name column)", {
  dat  <- make_data(n = 8, p = 3)
  tmp  <- tempfile(fileext = ".csv")
  .save_matrix(dat, tmp, id_col = "PersonID")

  back <- read.csv(tmp, check.names = FALSE)
  expect_equal(nrow(back), nrow(dat))
  expect_equal(ncol(back), ncol(dat) + 1L)    # PersonID + items
  expect_equal(colnames(back)[1], "PersonID")
  expect_equal(back$PersonID, rownames(dat))
})

test_that("save_guttman=TRUE writes XLSX with Guttman-ordered rows", {
  dat    <- make_data()
  tmp_g  <- tempfile(fileext = ".xlsx")
  result <- guttman_impute(dat, save_guttman = TRUE,
                            guttman_file = tmp_g, verbose = FALSE)

  back <- openxlsx::read.xlsx(tmp_g)
  expect_equal(nrow(back), nrow(dat))
  expect_equal(ncol(back), ncol(dat) + 1L)

  # Row order in file must match Guttman order
  expect_equal(back$PersonID, rownames(result$guttman_data))
})

test_that("save_imputed=TRUE writes XLSX with original row/col order", {
  dat    <- make_data()
  tmp_i  <- tempfile(fileext = ".xlsx")
  result <- guttman_impute(dat, save_imputed = TRUE,
                            imputed_file = tmp_i, verbose = FALSE)

  back <- openxlsx::read.xlsx(tmp_i)
  expect_equal(nrow(back), nrow(dat))
  expect_equal(ncol(back), ncol(dat) + 1L)

  # Row order in imputed file must match ORIGINAL order
  expect_equal(back$PersonID, rownames(dat))
  # Column names (items) must match original order
  expect_equal(colnames(back)[-1], colnames(dat))
})

# ── input validation ──────────────────────────────────────────────────────────

test_that("guttman_impute validates msq and z inputs", {
  dat <- make_data()
  expect_error(guttman_impute(dat, msq_lower = -0.1), "msq_lower")
  expect_error(guttman_impute(dat, msq_upper = 0.5),  "msq_upper")
  expect_error(guttman_impute(dat, z_threshold = 0),  "z_threshold")
  expect_error(guttman_impute(dat, k = 0),            "k")
})

# ── S3 methods ────────────────────────────────────────────────────────────────

test_that("print and summary methods work without error", {
  result <- guttman_impute(make_data(), verbose = FALSE)
  expect_output(print(result))
  expect_output(summary(result))
})
