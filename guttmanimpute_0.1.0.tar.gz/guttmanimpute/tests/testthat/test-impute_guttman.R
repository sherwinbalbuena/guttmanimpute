test_that("impute_guttman replaces intersection cells correctly", {
  # 5x5 matrix of 3s — any replacement should still round to 3
  mat <- matrix(3L, nrow = 5, ncol = 5,
                dimnames = list(paste0("P", 1:5), paste0("I", 1:5)))
  attr(mat, "orig_row_order") <- rownames(mat)
  attr(mat, "orig_col_order") <- colnames(mat)

  result <- impute_guttman(mat,
                            misfit_persons = c("P2", "P3"),
                            misfit_items   = c("I2", "I4"))

  # All neighbours are 3, so imputed value should still be 3
  expect_equal(result["P2", "I2"], 3)
  expect_equal(result["P3", "I4"], 3)
})

test_that("impute_guttman records the correct log", {
  set.seed(99)
  mat <- matrix(sample(1:5, 25, replace = TRUE), nrow = 5,
                dimnames = list(paste0("P", 1:5), paste0("I", 1:5)))
  attr(mat, "orig_row_order") <- rownames(mat)
  attr(mat, "orig_col_order") <- colnames(mat)

  result <- impute_guttman(mat,
                            misfit_persons = "P3",
                            misfit_items   = "I3")
  log <- attr(result, "imputed_log")

  expect_equal(nrow(log), 1L)
  expect_equal(log$person, "P3")
  expect_equal(log$item,   "I3")
  expect_true(log$n_neighbours <= 8L)
})

test_that("impute_guttman returns unchanged matrix when no misfits", {
  mat <- matrix(1:9, nrow = 3,
                dimnames = list(paste0("P", 1:3), paste0("I", 1:3)))
  attr(mat, "orig_row_order") <- rownames(mat)
  attr(mat, "orig_col_order") <- colnames(mat)

  result <- impute_guttman(mat, character(0), character(0))
  # Verify numeric values are unchanged (attributes will differ — result has
  # imputed_log in addition to orig_row/col_order; compare values only)
  expect_true(identical(result[1:3, 1:3], mat[1:3, 1:3]))
  expect_equal(nrow(attr(result, "imputed_log")), 0L)
})

test_that("impute_guttman errors without ordering attributes", {
  mat <- matrix(1:9, 3, 3,
                dimnames = list(paste0("P", 1:3), paste0("I", 1:3)))
  expect_error(impute_guttman(mat, "P1", "I1"), "orig_row_order")
})

test_that("impute_guttman handles edge cells (boundary clamping)", {
  # Target cell at corner (1,1)
  mat <- matrix(c(4,3,2,
                  3,1,3,
                  2,3,4), nrow = 3, byrow = TRUE,
                dimnames = list(c("P1","P2","P3"), c("I1","I2","I3")))
  attr(mat, "orig_row_order") <- rownames(mat)
  attr(mat, "orig_col_order") <- colnames(mat)

  result <- impute_guttman(mat,
                            misfit_persons = "P1",
                            misfit_items   = "I1")
  log <- attr(result, "imputed_log")

  # Corner cell has only 3 neighbours: (1,2), (2,1), (2,2)
  expect_equal(log$n_neighbours, 3L)
})
