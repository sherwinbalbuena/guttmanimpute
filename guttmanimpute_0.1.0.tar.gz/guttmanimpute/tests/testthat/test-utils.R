test_that(".to_matrix preserves NULL rownames by assigning P1..Pn", {
  mat <- matrix(1:12, nrow = 3)   # rownames = NULL
  result <- .to_matrix(mat)
  expect_equal(rownames(result), c("P1", "P2", "P3"))
})

test_that(".to_matrix preserves numeric-string rownames ('1','2',...)", {
  df <- data.frame(matrix(sample(1:5, 15, replace = TRUE), nrow = 3,
                          dimnames = list(NULL, paste0("I", 1:5))))
  # data.frame default rownames are "1","2","3"
  expect_equal(rownames(df), c("1", "2", "3"))
  result <- .to_matrix(df)
  # Must keep the original "1","2","3" — NOT replace with "P1","P2","P3"
  expect_equal(rownames(result), c("1", "2", "3"))
})

test_that(".to_matrix preserves named rownames unchanged", {
  mat <- matrix(1:12, nrow = 3,
                dimnames = list(c("Alice", "Bob", "Carol"), paste0("I", 1:4)))
  result <- .to_matrix(mat)
  expect_equal(rownames(result), c("Alice", "Bob", "Carol"))
  expect_equal(colnames(result), paste0("I", 1:4))
})

test_that(".validate_save_path errors on non-existent directory", {
  bad <- file.path(tempdir(), "nonexistent_xyz_dir", "out.csv")
  expect_error(.validate_save_path(bad), "Directory does not exist")
})

test_that(".validate_save_path passes for a valid writable path", {
  good <- tempfile(fileext = ".csv")
  expect_true(.validate_save_path(good))
})
